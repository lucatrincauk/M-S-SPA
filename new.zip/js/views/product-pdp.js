var ProductDetails = Backbone.View.extend({
	template: Handlebars.compile(
		'<div class="row">' +
		'<div class="col-xs-12 col-sm-6 col-md-4">' +
		'<img src="photos/{{imagepath}}" class="img-polaroid" />' +
		'</div>' +
		'<div class="col-xs-12 col-sm-6 col-md-8">' +
		'<div class="page-header"><h1>{{name}} <small>{{category}}</small></h1></div>' +
		'<p>&pound;{{price}}</p>' +
		'<div class="swatchBox">{{#each colour}}' +
		'<div class="swatchItem {{this}}" data-colour="{{this}}"></div> ' +
		'{{/each}}</div>' +
		'<button type="button" class="btn btn-success">Add to basket</button>' +
		'</div></div>'
	),

	initialize: function  () {
		this.listenTo(this.model, "change", this.render);
	},
	addToBasket: function () {
		app.basketItems.add(this.model, 1);
		alert('Added to basket');
	},
	selectSwatch: function (e) {
		this.model.set({
			selectedColour: $(e.target).data('colour')
		});
		//console.log(this.model);
	},
	
	render: function () {
		this.$el.html(this.template(this.model.attributes));
		this.delegateEvents({
			'click .btn-success': 'addToBasket',
			'click .swatchItem': 'selectSwatch'
		});
		return this;
	}
});